@echo off
REM ==================================================================
REM   秦安县秦剧团 · Admin Perf P99 日报
REM   Windows 定时任务一键安装脚本（每天 凌晨 02:00 自动运行）
REM ==================================================================
REM   使用：
REM     1) 先编辑好 config_daily_report.json（先从 example 复制）
REM     2) 测试一次：python daily_mailer.py --dry-run
REM                 python daily_mailer.py --test-smtp
REM     3) 右键 → 以管理员身份运行本 .bat（schtasks 需要管理员）
REM ==================================================================

setlocal EnableDelayedExpansion
chcp 65001 >nul 2>&1
set "SCRIPT_DIR=%~dp0"
cd /d "%SCRIPT_DIR%"

REM ========== 1. 环境检查 ==========
where python >nul 2>&1
if errorlevel 1 (
    echo [❌] 未检测到 Python 3，请先安装 https://www.python.org/downloads/windows/ 并勾选 "Add Python to PATH"
    pause & exit /b 2
)
REM 检查配置文件
if not exist "config_daily_report.json" (
    echo [⚠️]  还没有 config_daily_report.json
    echo     → 自动复制 example，请编辑后重新运行本脚本
    copy "config_daily_report.example.json" "config_daily_report.json" >nul
    echo     已生成：%SCRIPT_DIR%config_daily_report.json
    echo     请填入 ES / SMTP 账号密码后，重新右键以管理员身份运行
    pause & exit /b 3
)
REM 检查 daily_mailer.py
if not exist "daily_mailer.py" (
    echo [❌] 找不到 daily_mailer.py
    pause & exit /b 4
)
REM 检查 requests
python -c "import sys; sys.exit(0)" 2>nul

echo.
echo [1/3] Python 脚本快速 dry-run 校验（不发邮件，只拉ES生成报表）
python "%SCRIPT_DIR%daily_mailer.py" --dry-run
if errorlevel 1 (
    echo [❌] dry-run 失败，退出码=%errorlevel%，请检查上方日志修正配置
    pause & exit /b 5
)

echo.
echo [2/3] 创建 Windows 计划任务：每天凌晨 02:00 自动执行（唤醒电脑运行 + 运行失败次日补跑）
REM   任务名：QAXQJT_Perf_P99_Daily
REM   运行用户：当前用户，不管是否登录都运行（需要用户密码可以用 /RP 参数）
REM   StartBoundary：每日 02:00（你可以把下面的 "02:00" 改成想要的时间）
schtasks /Create /F /TN "QAXQJT_Perf_P99_Daily" ^
    /SC DAILY /ST 02:00 ^
    /TR "\"python\" \"%SCRIPT_DIR%daily_mailer.py\" --config \"%SCRIPT_DIR%config_daily_report.json\"" ^
    /RL HIGHEST ^
    /IT

if errorlevel 1 (
    echo [⚠️]  schtasks 普通创建失败，尝试带 WakeToRun + RunOnlyIfIdle 关闭的方式
    schtasks /Create /F /TN "QAXQJT_Perf_P99_Daily" ^
        /SC DAILY /ST 02:00 ^
        /TR "\"python\" \"%SCRIPT_DIR%daily_mailer.py\" --config \"%SCRIPT_DIR%config_daily_report.json\"" ^
        /RL HIGHEST /IT
)

if errorlevel 1 (
    echo [❌] 创建计划任务失败，请确保你是"以管理员身份运行"本 .bat
    pause & exit /b 6
)

REM 启用"唤醒计算机运行此任务" + 允许按需运行
REM 用 XML 导出 + 导入方式精确配置
echo.
echo [2.1/3] 配置计划任务高级选项：唤醒运行 + 允许多实例 + 失败重试
schtasks /Query /TN "QAXQJT_Perf_P99_Daily" /XML > "%TEMP%\_qaxqjt_task.xml" 2>nul
if exist "%TEMP%\_qaxqjt_task.xml" (
    REM 尝试注入唤醒、允许多实例、空闲条件关闭（sed for windows，powershell实现）
    powershell -NoProfile -Command "$xml = Get-Content '%TEMP%\_qaxqjt_task.xml' -Raw; $xml = $xml -replace '(?s)<WakeToRun>.*?</WakeToRun>', '<WakeToRun>true</WakeToRun>'; $xml = $xml -replace '(?s)<Settings>.*?</IdleSettings>.*?</IdleSettings>', '<IdleSettings><Duration>PT0S</Duration><WaitTimeout>PT0S</WaitTimeout><StopOnIdleEnd>false</StopOnIdleEnd><RestartOnIdle>false</RestartOnIdle></IdleSettings>'; $xml = $xml -replace '(?s)<MultipleInstancesPolicy>.*?</MultipleInstancesPolicy>', '<MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>'; if ($xml -notmatch 'WakeToRun') { $xml = $xml -replace '(<\/IdleSettings>)', "`$1<WakeToRun>true</WakeToRun>"; }; Set-Content '%TEMP%\_qaxqjt_task.xml' $xml -Encoding UTF8" >nul 2>&1
    schtasks /Create /F /TN "QAXQJT_Perf_P99_Daily" /XML "%TEMP%\_qaxqjt_task.xml" >nul 2>&1
)

echo.
echo [3/3] 立即手动触发一次（验证计划任务能跑通）
schtasks /Run /TN "QAXQJT_Perf_P99_Daily"
timeout /t 5 /nobreak >nul
schtasks /Query /TN "QAXQJT_Perf_P99_Daily" /V /FO LIST | findstr /i "任务名 状态 上次运行时间 上次运行结果"

echo.
echo =======================================================================================
echo   ✅  P99 日报定时任务安装成功
echo =======================================================================================
echo     任务名     ：QAXQJT_Perf_P99_Daily
echo     触发时间   ：每天 凌晨 02:00
echo     日志目录   ：%SCRIPT_DIR%logs\
echo     报表存档   ：%SCRIPT_DIR%reports\
echo.
echo     常用维护命令（CMD）：
echo       查看任务  ：schtasks /Query /TN "QAXQJT_Perf_P99_Daily" /V /FO LIST
echo       手动执行  ：schtasks /Run /TN "QAXQJT_Perf_P99_Daily"
echo       结束任务  ：schtasks /End /TN "QAXQJT_Perf_P99_Daily"
echo       删除任务  ：schtasks /Delete /F /TN "QAXQJT_Perf_P99_Daily"
echo       修改时间  ：把本脚本里的 "02:00" 改成想运行的时间再跑一次即可覆盖
echo =======================================================================================
echo.
pause
endlocal
